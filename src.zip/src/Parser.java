import java.util.ArrayList;
import java.util.HashMap;

public class Parser {
    private ArrayList<Token> tokenList;
    private ArrayList<String> parseList;
    private int tkPtr;
    private Token curToken;
    private int level;
    private ArrayList<SymbolTableItem> globalSymbolTable;
    private HashMap<String, ArrayList<SymbolTableItem>> localSymbolTable;

    public Parser(ArrayList<Token> tokenList) {
        this.tokenList = tokenList;
        tokenList.add(new Token("end", SymbolType.END, 0));
        this.parseList = new ArrayList<>();
        this.tkPtr = 1;
        this.curToken = tokenList.get(0);
        this.level = 1;
        this.globalSymbolTable = new ArrayList<>();
        this.localSymbolTable = new HashMap<>();
        this.analyze();
    }

    public void analyze() {
        Node CompUnit = new Node("CompUnit");
        CompUnit(CompUnit);
        System.out.println(">>>>>>>>>> Parser End <<<<<<<<<<");
//        recrusiveOutputTree(CompUnit);
    }

    private void insertTable(String name, String value, int type, int dimension, int paramNum, int address) {
        if (level == 1) {
            //当前在最外层
            globalSymbolTable.add(new SymbolTableItem(name, value, type, level, dimension, paramNum, address));
        } else {
            ArrayList<SymbolTableItem> lst = localSymbolTable.get(globalSymbolTable.get(globalSymbolTable.size() - 1).name);
            if (lst == null) {
                localSymbolTable.put(globalSymbolTable.get(globalSymbolTable.size() - 1).name, new ArrayList<SymbolTableItem>());
                lst = localSymbolTable.get(globalSymbolTable.get(globalSymbolTable.size() - 1).name);
            }
            lst.add(new SymbolTableItem(name, value, type, level, dimension, paramNum, address));
        }
    }

    private boolean checkTable(String name) {
        //检查当前name是否能插入，不能返回false
        //标识符只要在当前层次不重名就可以了，局部变量和函数也可以重名！（长知识了QAQ）
        if (level == 1) {
            for (SymbolTableItem sti : globalSymbolTable) {
                if (sti.name.equals(name)) {
                    return false;
                }
            }
        } else {
            ArrayList<SymbolTableItem> LST = localSymbolTable.get(globalSymbolTable.get(globalSymbolTable.size() - 1).name);
            if (LST != null) {
                for (SymbolTableItem sti : LST) {
                    if (sti.name.equals(name)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public void recrusiveOutputTree(Node node) {
        for (Node child : node.getChildNode()) {
            recrusiveOutputTree(child);
        }
        System.out.println(node.getName());
    }

    public void getToken(Node node) {
        parseList.add(curToken.getType() + " " + curToken.getContent());
        Node tNode = new Node(curToken);
        addRelation(node, tNode);
//        System.out.println(curToken.getType() + " " + curToken.getContent());
        curToken = tokenList.get(tkPtr);
        tkPtr++;
    }

    public void addRelation(Node parent, Node child) {
        parent.addChildNode(child);
        child.setParNode(parent);
    }

    public ArrayList<String> getParseList() {
        return parseList;
    }

    public void error() {
        System.out.println("error");
        System.out.println(curToken.getType() + " " + curToken.getContent() + " " + curToken.getLine());
    }

    public void CompUnit(Node CompUnit) {
//        Node CompUnit = new Node("CompUnit");
        while (curToken.type == SymbolType.CONSTTK ||
                (curToken.type == SymbolType.INTTK && tokenList.get(tkPtr).type == SymbolType.IDENFR &&
                        (tokenList.get(tkPtr + 1).type == SymbolType.LBRACK || tokenList.get(tkPtr + 1).type == SymbolType.ASSIGN || tokenList.get(tkPtr + 1).type == SymbolType.SEMICN || tokenList.get(tkPtr + 1).type == SymbolType.COMMA))) {
            Decl(CompUnit);
        }
        while ((curToken.type == SymbolType.VOIDTK || curToken.type == SymbolType.INTTK) && tokenList.get(tkPtr).type == SymbolType.IDENFR && tokenList.get(tkPtr + 1).type == SymbolType.LPARENT) {
            FuncDef(CompUnit);
        }
        if (curToken.type == SymbolType.INTTK && tokenList.get(tkPtr).type == SymbolType.MAINTK) {
            MainFuncDef(CompUnit);
        } else {
            error();
        }
        parseList.add("<CompUnit>");
    }

    public void Decl(Node node) {
        Node Decl = new Node("Decl");
        addRelation(node, Decl);
        if (curToken.type == SymbolType.CONSTTK) {
            ConstDecl(Decl);
        } else if (curToken.type == SymbolType.INTTK) {
            VarDecl(Decl);
        } else {
            error();
        }
    }

    public void FuncDef(Node node) {
        Node FuncDef = new Node("FuncDef");
        addRelation(node, FuncDef);
        FuncType(FuncDef);
        if (curToken.type == SymbolType.IDENFR) {
            getToken(FuncDef);
            if (curToken.type == SymbolType.LPARENT) {
                getToken(FuncDef);
                if (curToken.type == SymbolType.RPARENT) {
                    getToken(FuncDef);
                    Block(FuncDef);
                } else {
                    FuncFParams(FuncDef);
                    if (curToken.type == SymbolType.RPARENT) {
                        getToken(FuncDef);
                        Block(FuncDef);
                    } else {
                        error();
                    }
                }
            }
        } else {
            error();
        }
        parseList.add("<FuncDef>");
    }

    public void FuncType(Node node) {
        Node FuncType = new Node("FuncType");
        addRelation(node, FuncType);
        if (curToken.type == SymbolType.VOIDTK || curToken.type == SymbolType.INTTK) {
            getToken(FuncType);
        } else {
            error();
        }
        parseList.add("<FuncType>");
    }

    public void MainFuncDef(Node node) {
        Node MainFuncDef = new Node("MainFuncDef");
        addRelation(node, MainFuncDef);
        getToken(MainFuncDef);
        getToken(MainFuncDef);
        if (curToken.type == SymbolType.LPARENT) {
            getToken(MainFuncDef);
            if (curToken.type == SymbolType.RPARENT) {
                getToken(MainFuncDef);
                Block(MainFuncDef);
            } else {
                error();
            }
        } else {
            error();
        }
        parseList.add("<MainFuncDef>");
    }

    public void Block(Node node) {
        Node Block = new Node("Block");
        addRelation(node, Block);
        if (curToken.type == SymbolType.LBRACE) {
            getToken(Block);
            if (curToken.type == SymbolType.RBRACE) {
                getToken(Block);
            } else {
                while (curToken.type != SymbolType.RBRACE) {
                    BlockItem(Block);
                }
                if (curToken.type == SymbolType.RBRACE) {
                    getToken(Block);
                } else {
                    error();
                }
            }
        } else {
            error();
        }
        parseList.add("<Block>");
    }

    public void BlockItem(Node node) {
        Node BlockItem = new Node("BlockItem");
        addRelation(node, BlockItem);
        if (curToken.type == SymbolType.CONSTTK || curToken.type == SymbolType.INTTK) {
            Decl(BlockItem);
        } else if (curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.IFTK || curToken.type == SymbolType.WHILETK
                || curToken.type == SymbolType.BREAKTK || curToken.type == SymbolType.CONTINUETK || curToken.type == SymbolType.RETURNTK
                || curToken.type == SymbolType.PRINTFTK || curToken.type == SymbolType.SEMICN || curToken.type == SymbolType.LBRACE
                || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU
                || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
            Stmt(BlockItem);
        }
    }

    public void Stmt(Node node) {
        Node Stmt = new Node("Stmt");
        addRelation(node, Stmt);
        if (curToken.type == SymbolType.IFTK) {
            getToken(Stmt);
            if (curToken.type == SymbolType.LPARENT) {
                getToken(Stmt);
                Cond(Stmt);
                if (curToken.type == SymbolType.RPARENT) {
                    getToken(Stmt);
                    Stmt(Stmt);
                } else {
                    error();
                }
                while (curToken.type == SymbolType.ELSETK) {
                    getToken(Stmt);
                    Stmt(Stmt);
                }
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.WHILETK) {
            getToken(Stmt);
            if (curToken.type == SymbolType.LPARENT) {
                getToken(Stmt);
                Cond(Stmt);
                if (curToken.type == SymbolType.RPARENT) {
                    getToken(Stmt);
                    Stmt(Stmt);
                } else {
                    error();
                }
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.BREAKTK) {
            getToken(Stmt);
            if (curToken.type == SymbolType.SEMICN) {
                getToken(Stmt);
            }
        } else if (curToken.type == SymbolType.CONTINUETK) {
            getToken(Stmt);
            if (curToken.type == SymbolType.SEMICN) {
                getToken(Stmt);
            }
        } else if (curToken.type == SymbolType.RETURNTK) {
            getToken(Stmt);
            if (curToken.type == SymbolType.SEMICN) {
                getToken(Stmt);
            } else if (curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.INTCON || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT) {
                Exp(Stmt);
                if (curToken.type == SymbolType.SEMICN) {
                    getToken(Stmt);
                } else {
                    error();
                }
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.PRINTFTK) {
            getToken(Stmt);
            if (curToken.type == SymbolType.LPARENT) {
                getToken(Stmt);
                if (curToken.type == SymbolType.STRCON) {
                    getToken(Stmt);
                    while (curToken.type == SymbolType.COMMA) {
                        getToken(Stmt);
                        Exp(Stmt);
                    }
                    if (curToken.type == SymbolType.RPARENT) {
                        getToken(Stmt);
                        if (curToken.type == SymbolType.SEMICN) {
                            getToken(Stmt);
                        } else {
                            error();
                        }
                    } else {
                        error();
                    }
                } else {
                    error();
                }
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.LBRACE) {
            Block(Stmt);
        } else if (curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.INTCON || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT) {
            Exp(Stmt);
            if (curToken.type == SymbolType.SEMICN) {
                getToken(Stmt);
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.IDENFR) {
            int ptr = tkPtr;
            int assignFlag = 0;
            Token temp = tokenList.get(ptr);
            while (temp.type != SymbolType.SEMICN) {
                if (temp.type == SymbolType.ASSIGN) {
                    assignFlag = 1;
                    break;
                }
                ptr++;
                temp = tokenList.get(ptr);
            }
            if (assignFlag == 1) {
                if (tokenList.get(ptr + 1).type == SymbolType.GETINTTK) {
                    LVal(Stmt);
                    if (curToken.type == SymbolType.ASSIGN) {
                        getToken(Stmt);
                        if (curToken.type == SymbolType.GETINTTK) {
                            getToken(Stmt);
                            if (curToken.type == SymbolType.LPARENT) {
                                getToken(Stmt);
                                if (curToken.type == SymbolType.RPARENT) {
                                    getToken(Stmt);
                                    if (curToken.type == SymbolType.SEMICN) {
                                        getToken(Stmt);
                                    }
                                } else {
                                    error();
                                }
                            } else {
                                error();
                            }
                        } else {
                            error();
                        }
                    } else {
                        error();
                    }
                }
                else if (tokenList.get(ptr + 1).type == SymbolType.LPARENT || tokenList.get(ptr + 1).type == SymbolType.IDENFR || tokenList.get(ptr + 1).type == SymbolType.PLUS || tokenList.get(ptr + 1).type == SymbolType.MINU || tokenList.get(ptr + 1).type == SymbolType.NOT || tokenList.get(ptr + 1).type == SymbolType.INTCON) {
                    LVal(Stmt);
                    if (curToken.type == SymbolType.ASSIGN) {
                        getToken(Stmt);
                        if (curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
                            Exp(Stmt);
                            if (curToken.type == SymbolType.SEMICN) {
                                getToken(Stmt);
                            } else {
                                error();
                            }
                        } else {
                            error();
                        }
                    } else {
                        error();
                    }
                } else {
                    error();
                }
            } else {
                Exp(Stmt);
                if (curToken.type == SymbolType.SEMICN) {
                    getToken(Stmt);
                } else {
                    error();
                }
            }
        } else if (curToken.type == SymbolType.SEMICN) {
            getToken(Stmt);
        } else {
            error();
        }
        parseList.add("<Stmt>");
    }

    public void Cond(Node node) {
        Node Cond = new Node("Cond");
        addRelation(node, Cond);
        if (curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.INTCON || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT) {
            LOrExp(Cond);
        }
        parseList.add("<Cond>");
    }

    public void LOrExp(Node node) {
        Node LOrExp = new Node("LOrExp");
        addRelation(node, LOrExp);
        LAndExp(LOrExp);
        parseList.add("<LOrExp>");
        while (curToken.type == SymbolType.OR) {
            getToken(LOrExp);
            LAndExp(LOrExp);
            parseList.add("<LOrExp>");
        }
    }

    public void LAndExp(Node node) {
        Node LAndExp = new Node("LAndExp");
        addRelation(node, LAndExp);
        EqExp(LAndExp);
        parseList.add("<LAndExp>");
        while (curToken.type == SymbolType.AND) {
            getToken(LAndExp);
            EqExp(LAndExp);
            parseList.add("<LAndExp>");
        }
    }

    public void EqExp(Node node) {
        Node EqExp = new Node("EqExp");
        addRelation(node, EqExp);
        RelExp(EqExp);
        parseList.add("<EqExp>");
        while (curToken.type == SymbolType.EQL || curToken.type == SymbolType.NEQ) {
            getToken(EqExp);
            RelExp(EqExp);
            parseList.add("<EqExp>");
        }
    }

    public void RelExp(Node node) {
        Node RelExp = new Node("RelExp");
        addRelation(node, RelExp);
        AddExp(RelExp);
        parseList.add("<RelExp>");
        while (curToken.type == SymbolType.LSS || curToken.type == SymbolType.LEQ || curToken.type == SymbolType.GRE || curToken.type == SymbolType.GEQ) {
            getToken(RelExp);
            AddExp(RelExp);
            parseList.add("<RelExp>");
        }
    }

    public void ConstDecl(Node node) {
        Node ConstDecl = new Node("ConstDecl");
        addRelation(node, ConstDecl);
        if (curToken.type == SymbolType.CONSTTK) {
            getToken(ConstDecl);
            if (curToken.type == SymbolType.INTTK) {
                getToken(ConstDecl);
                ConstDef(ConstDecl);
                while (curToken.type == SymbolType.COMMA) {
                    getToken(ConstDecl);
                    ConstDef(ConstDecl);
                }
                if (curToken.type == SymbolType.SEMICN) {
                    getToken(ConstDecl);
                    parseList.add("<ConstDecl>");
                } else {
                    error();
                }
            } else {
                error();
            }
        } else {
            error();
        }
    }

    public void ConstDef(Node node) {
        Node ConstDef = new Node("ConstDef");
        addRelation(node, ConstDef);
        if (curToken.type == SymbolType.IDENFR) {
            getToken(ConstDef);
            while (curToken.type == SymbolType.LBRACK) {
                getToken(ConstDef);
                ConstExp(ConstDef);
                if (curToken.type == SymbolType.RBRACK) {
                    getToken(ConstDef);
                } else {
                    error();
                }
            }
            if (curToken.type == SymbolType.ASSIGN) {
                getToken(ConstDef);
                ConstInitVal(ConstDef);
            } else {
                error();
            }
            parseList.add("<ConstDef>");
        } else {
            error();
        }
    }

    public void VarDecl(Node node) {
        Node VarDecl = new Node("VarDecl");
        addRelation(node, VarDecl);
        if (curToken.type == SymbolType.INTTK) {
            getToken(VarDecl);
            VarDef(VarDecl);
            while (curToken.type == SymbolType.COMMA) {
                getToken(VarDecl);
                VarDef(VarDecl);
            }
            if (curToken.type == SymbolType.SEMICN) {
                getToken(VarDecl);
                parseList.add("<VarDecl>");
            } else {
                error();
            }
        } else {
            error();
        }
    }

    public void VarDef(Node node) {
        Node VarDef = new Node("VarDef");
        addRelation(node, VarDef);
        if (curToken.type == SymbolType.IDENFR) {
            getToken(VarDef);
            while (curToken.type == SymbolType.LBRACK) {
                getToken(VarDef);
                ConstExp(VarDef);
                if (curToken.type == SymbolType.RBRACK) {
                    getToken(VarDef);
                } else {
                    error();
                }
            }
            if (curToken.type == SymbolType.ASSIGN) {
                getToken(VarDef);
                InitVal(VarDef);
                if (curToken.type != SymbolType.COMMA && curToken.type != SymbolType.SEMICN) {
                    error();
                }
            }
            parseList.add("<VarDef>");
        } else {
            error();
        }
    }

    public void ConstInitVal(Node node) {
        Node ConstInitVal = new Node("ConstInitVal");
        addRelation(node, ConstInitVal);
        if (curToken.type == SymbolType.LBRACE) {
            getToken(ConstInitVal);
            if (curToken.type == SymbolType.LBRACE || curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
                ConstInitVal(ConstInitVal);
                while (curToken.type == SymbolType.COMMA) {
                    getToken(ConstInitVal);
                    ConstInitVal(ConstInitVal);
                }
                if (curToken.type == SymbolType.RBRACE) {
                    getToken(ConstInitVal);
                }
            } else if (curToken.type == SymbolType.RBRACE) {
                getToken(ConstInitVal);
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
            ConstExp(ConstInitVal);
        } else {
            error();
        }
        parseList.add("<ConstInitVal>");
    }

    public void InitVal(Node node) {
        Node InitVal = new Node("InitVal");
        addRelation(node, InitVal);
        if (curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
            Exp(InitVal);
            parseList.add("<InitVal>");
        } else if (curToken.type == SymbolType.LBRACE) {
            getToken(InitVal);
            if (curToken.type == SymbolType.RBRACE) {
                getToken(InitVal);
            } else if (curToken.type == SymbolType.LBRACE || curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
                InitVal(InitVal);
                while (curToken.type == SymbolType.COMMA) {
                    getToken(InitVal);
                    InitVal(InitVal);
                }
                if (curToken.type == SymbolType.RBRACE) {
                    getToken(InitVal);
                    parseList.add("<InitVal>");
                } else {
                    error();
                }
            }
        } else {
            error();
        }
    }

    public void ConstExp(Node node) {
        Node ConstExp = new Node("ConstExp");
        addRelation(node, ConstExp);
        AddExp(ConstExp);
        parseList.add("<ConstExp>");
    }

    public void AddExp(Node node) {
        Node AddExp = new Node("AddExp");
        addRelation(node, AddExp);
        MulExp(AddExp);
        parseList.add("<AddExp>");
        while (curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU) {
            getToken(AddExp);
            MulExp(AddExp);
            parseList.add("<AddExp>");
        }
    }

    public void MulExp(Node node) {
        Node MulExp = new Node("MulExp");
        addRelation(node, MulExp);
        UnaryExp(MulExp);
        parseList.add("<MulExp>");
        while (curToken.type == SymbolType.MULT || curToken.type == SymbolType.DIV || curToken.type == SymbolType.MOD) {
            getToken(MulExp);
            UnaryExp(MulExp);
            parseList.add("<MulExp>");
        }
    }

    public void UnaryExp(Node node) {
        Node UnaryExp = new Node("UnaryExp");
        addRelation(node, UnaryExp);
        if (curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.INTCON || (curToken.type == SymbolType.IDENFR && tokenList.get(tkPtr).type != SymbolType.LPARENT)) {
            PrimaryExp(UnaryExp);
        } else if (curToken.type == SymbolType.IDENFR && tokenList.get(tkPtr).type == SymbolType.LPARENT) {
            getToken(UnaryExp);
            getToken(UnaryExp);
            if (curToken.type == SymbolType.RPARENT) {
                getToken(UnaryExp);
            } else if (curToken.type == SymbolType.IDENFR || curToken.type == SymbolType.LPARENT || curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT || curToken.type == SymbolType.INTCON) {
                FuncRParams(UnaryExp);
                if (curToken.type == SymbolType.RPARENT) {
                    getToken(UnaryExp);
                } else {
                    error();
                }
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.PLUS || curToken.type == SymbolType.MINU || curToken.type == SymbolType.NOT) {
            UnaryOp(UnaryExp);
            UnaryExp(UnaryExp);
        } else {
            error();
        }
        parseList.add("<UnaryExp>");
    }

    public void UnaryOp(Node node) {
        Node UnaryOp = new Node("UnaryOp");
        addRelation(node, UnaryOp);
        getToken(UnaryOp);
        parseList.add("<UnaryOp>");
    }

    public void PrimaryExp(Node node) {
        Node PrimaryExp = new Node("PrimaryExp");
        addRelation(node, PrimaryExp);
        if (curToken.type == SymbolType.LPARENT) {
            getToken(PrimaryExp);
            Exp(PrimaryExp);
            if (curToken.type == SymbolType.RPARENT) {
                getToken(PrimaryExp);
            } else {
                error();
            }
        } else if (curToken.type == SymbolType.IDENFR) {
            LVal(PrimaryExp);
        } else if (curToken.type == SymbolType.INTCON) {
            Number(PrimaryExp);
        } else {
            error();
        }
        parseList.add("<PrimaryExp>");
    }

    public void Number(Node node) {
        Node Number = new Node("Number");
        addRelation(node, Number);
        getToken(Number);
        parseList.add("<Number>");
    }

    public void LVal(Node node) {
        Node LVal = new Node("LVal");
        addRelation(node, LVal);
        getToken(LVal);
        while (curToken.type == SymbolType.LBRACK) {
            getToken(LVal);
            Exp(LVal);
            if (curToken.type == SymbolType.RBRACK) {
                getToken(LVal);
            } else {
                error();
            }
        }
        parseList.add("<LVal>");
    }

    public void FuncFParams(Node node) {
        Node FuncFParams = new Node("FuncFParams");
        addRelation(node, FuncFParams);
        FuncFParam(FuncFParams);
        while (curToken.type == SymbolType.COMMA) {
            getToken(FuncFParams);
            FuncFParam(FuncFParams);
        }
        parseList.add("<FuncFParams>");
    }

    public void FuncFParam(Node node) {
        Node FuncFParam = new Node("FuncFParam");
        addRelation(node, FuncFParam);
        if (curToken.type == SymbolType.INTTK) {
            getToken(FuncFParam);
            if (curToken.type == SymbolType.IDENFR) {
                getToken(FuncFParam);
                if (curToken.type == SymbolType.LBRACK) {
                    getToken(FuncFParam);
                    if (curToken.type == SymbolType.RBRACK) {
                        getToken(FuncFParam);
                        while (curToken.type == SymbolType.LBRACK) {
                            getToken(FuncFParam);
                            ConstExp(FuncFParam);
                            if (curToken.type == SymbolType.RBRACK) {
                                getToken(FuncFParam);
                            } else {
                                error();
                            }
                        }
                        parseList.add("<FuncFParam>");
                    } else {
                        error();
                    }
                } else if (curToken.type == SymbolType.COMMA || curToken.type == SymbolType.RPARENT) {
                    parseList.add("<FuncFParam>");
                } else {
                    error();
                }
            } else {
                error();
            }
        } else {
            error();
        }
    }

    public void FuncRParams(Node node) {
        Node FuncRParams = new Node("FuncRParams");
        addRelation(node, FuncRParams);
        Exp(FuncRParams);
        while (curToken.type == SymbolType.COMMA) {
            getToken(FuncRParams);
            Exp(FuncRParams);
        }
        parseList.add("<FuncRParams>");
    }

    public void Exp(Node node) {
        Node Exp = new Node("Exp");
        addRelation(node, Exp);
        AddExp(Exp);
        parseList.add("<Exp>");
    }
}
