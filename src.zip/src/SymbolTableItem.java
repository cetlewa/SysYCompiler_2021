public class SymbolTableItem {
    public String name;    //标识符名：常量，变量，过程
    private String value;   //变量值
    private int type;
    private int level;
    private int dimension;
    private int paramNum;
    public int address;

    public SymbolTableItem(String name, String value, int type, int level, int dimension, int  paramNum, int address) {
        this.name = name;
        this.value = value;
        this.type = type;
        this.level = level;
        this.dimension = dimension;
        this.paramNum = paramNum;
        this.address = address;
    }
}
