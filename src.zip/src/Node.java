import java.util.ArrayList;

public class Node {
    private String name;    // CompUnit, {, [, id ...
    private Token token;
    private Node parNode;
    private ArrayList<Node> childNode = new ArrayList<>();

    public Node(String nTerminal) {
        this.name = nTerminal;
    }

    public Node(Token token) {
        this.token = token;
    }

    public void setParNode(Node parNode) {
        this.parNode = parNode;
    }

    public void addChildNode(Node childNode) {
        this.childNode.add(childNode);
    }

    public ArrayList<Node> getChildNode() {
        return this.childNode;
    }

    public String getName() {
        if (this.token == null) {
            return "<" + this.name + ">";
        } else {
            return this.token.getType() + " " + this.token.getContent();
        }
    }
}


