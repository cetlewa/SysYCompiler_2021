import java.util.ArrayList;

public class Lexer {
    private String code;
    private ArrayList<Token> tokenList;
    private String[] resWords = {"main", "const", "int", "break", "continue", "if", "else", "while", "getint", "printf", "return", "void"};

    public Lexer(String code) {
        this.code = code;
        this.tokenList = new ArrayList<>();
        this.analyze();
    }

    public void analyze() {
        int charPtr = 0;
        int curLine = 1;
        int codeLen = code.length();
        while (charPtr < codeLen) {
            String tokenContent = "";
            SymbolTable tokenType;

            // filter space and get current line
            while (charPtr < codeLen && (code.charAt(charPtr) == '\n' || code.charAt(charPtr) == '\t' || code.charAt(charPtr) == '\r' || code.charAt(charPtr) == '\0' || code.charAt(charPtr) == ' ')) {
                if (code.charAt(charPtr) == '\n') curLine++;
                charPtr++;
            }
            if (charPtr >= codeLen) break;

            // identifier and reserved words
            if (Character.isLetter(code.charAt(charPtr)) || code.charAt(charPtr) == '_') {
                while (charPtr < codeLen && (Character.isLetter(code.charAt(charPtr)) || Character.isDigit(code.charAt(charPtr))) || code.charAt(charPtr) == '_' ) {
                    tokenContent += code.charAt(charPtr);
                    charPtr++;
                }
                tokenType = SymbolTable.IDENFR;
                // judge for reserved words
                for (int j = 0; j < resWords.length; j++) {
                    if (tokenContent.equals(resWords[j])) {
                        tokenType = SymbolTable.values()[j];
                        break;
                    }
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // digit number
            else if (Character.isDigit(code.charAt(charPtr))) {
                tokenContent = "";
                while (charPtr < codeLen && Character.isDigit(code.charAt(charPtr))) {
                    tokenContent += code.charAt(charPtr);
                    charPtr++;
                }
                tokenType = SymbolTable.INTCON;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // "xxx"
            else if (code.charAt(charPtr) == '"') {
                tokenContent += code.charAt(charPtr);
                charPtr++;
                while (charPtr < codeLen && code.charAt(charPtr) != '"' && code.charAt(charPtr) != '\n') {
                    tokenContent += code.charAt(charPtr);
                    charPtr++;
                }
                if (charPtr < codeLen && code.charAt(charPtr) == '\"') {
                    tokenContent += code.charAt(charPtr);
                    tokenType = SymbolTable.STRCON;
                    tokenList.add(new Token(tokenContent, tokenType, curLine));
                    charPtr++;
                }
            }

            // ! and !=
            else if (code.charAt(charPtr) == '!') {
                tokenContent = "!";
                tokenType = SymbolTable.NOT;
                charPtr++;
                if (code.charAt(charPtr) == '=') {
                    tokenContent = "!=";
                    tokenType = SymbolTable.NEQ;
                    charPtr++;
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // &&
            else if (code.charAt(charPtr) == '&') {
                tokenContent = "&";
                tokenType = SymbolTable.AND;
                charPtr++;
                if (code.charAt(charPtr) == '&') {
                    tokenContent = "&&";
                    tokenType = SymbolTable.AND;
                    charPtr++;
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // ||
            else if (code.charAt(charPtr) == '|') {
                tokenContent = "|";
                tokenType = SymbolTable.OR;
                charPtr++;
                if (code.charAt(charPtr) == '|') {
                    tokenContent = "||";
                    tokenType = SymbolTable.OR;
                    charPtr++;
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // +
            else if (code.charAt(charPtr) == '+') {
                tokenContent = "+";
                tokenType = SymbolTable.PLUS;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // -
            else if (code.charAt(charPtr) == '-') {
                tokenContent = "-";
                tokenType = SymbolTable.MINU;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // *
            else if (code.charAt(charPtr) == '*') {
                tokenContent = "*";
                tokenType = SymbolTable.MULT;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // / and annotation handle
            else if (code.charAt(charPtr) == '/') {
                tokenContent = "/";
                tokenType = SymbolTable.DIV;
                charPtr++;

                //handle annotation
                if (code.charAt(charPtr) == '/') {
                    charPtr++;
                    while (charPtr < codeLen) {
                        if (code.charAt(charPtr) == '\n') {
                            curLine++;
                            charPtr++;
                            break;
                        }
                        charPtr++;
                    }
                }
                else if (code.charAt(charPtr) == '*') {
                    charPtr++;
                    while (charPtr < codeLen - 1 && (code.charAt(charPtr) != '*' || code.charAt(charPtr + 1) != '/')) {
                        if (code.charAt(charPtr) == '\n') {
                            curLine++;
                        }
                        charPtr++;
                    }
                    if (charPtr < codeLen - 1) {
                        charPtr += 2;
                    }
                }

                else {
                    tokenList.add(new Token(tokenContent, tokenType, curLine));
                }
            }

            // %
            else if (code.charAt(charPtr) == '%') {
                tokenContent = "%";
                tokenType = SymbolTable.MOD;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // < and <=
            else if (code.charAt(charPtr) == '<') {
                tokenContent = "<";
                tokenType = SymbolTable.LSS;
                charPtr++;
                if (code.charAt(charPtr) == '=') {
                    tokenContent = "<=";
                    tokenType = SymbolTable.LEQ;
                    charPtr++;
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // > and >=
            else if (code.charAt(charPtr) == '>') {
                tokenContent = ">";
                tokenType = SymbolTable.GRE;
                charPtr++;
                if (code.charAt(charPtr) == '=') {
                    tokenContent = ">=";
                    tokenType = SymbolTable.GEQ;
                    charPtr++;
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // = and ==
            else if (code.charAt(charPtr) == '=') {
                tokenContent = "=";
                tokenType = SymbolTable.ASSIGN;
                charPtr++;
                if (code.charAt(charPtr) == '=') {
                    tokenContent = "==";
                    tokenType = SymbolTable.EQL;
                    charPtr++;
                }
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // ;
            else if (code.charAt(charPtr) == ';') {
                tokenContent = ";";
                tokenType = SymbolTable.SEMICN;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // ,
            else if (code.charAt(charPtr) == ',') {
                tokenContent = ",";
                tokenType = SymbolTable.COMMA;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // (
            else if (code.charAt(charPtr) == '(') {
                tokenContent = "(";
                tokenType = SymbolTable.LPARENT;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // )
            else if (code.charAt(charPtr) == ')') {
                tokenContent = ")";
                tokenType = SymbolTable.RPARENT;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // [
            else if (code.charAt(charPtr) == '[') {
                tokenContent = "[";
                tokenType = SymbolTable.LBRACK;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // ]
            else if (code.charAt(charPtr) == ']') {
                tokenContent = "]";
                tokenType = SymbolTable.RBRACK;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // {
            else if (code.charAt(charPtr) == '{') {
                tokenContent = "{";
                tokenType = SymbolTable.LBRACE;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            // )
            else if (code.charAt(charPtr) == '}') {
                tokenContent = "}";
                tokenType = SymbolTable.RBRACE;
                charPtr++;
                tokenList.add(new Token(tokenContent, tokenType, curLine));
            }

            else {
                charPtr++;
            }
        }
    }

    public ArrayList<Token> getTokenList() {
        return tokenList;
    }
}
