public class Token {
    public String content;
    public SymbolTable type;
    public int line;

    public Token(String symbol, SymbolTable type, int line) {
        this.content = symbol;
        this.type = type;
        this.line = line;
    }

    public String getContent() {
        return content;
    }

    public SymbolTable getType() {
        return type;
    }

    public int getLine() {
        return line;
    }
}
