import java.util.ArrayList;

public class Parser {
    private ArrayList<Token> tokenList;
    private ArrayList<String> parseList;
    public int tkPtr;
    public Token curToken;

    public Parser(ArrayList<Token> tokenList) {
        this.tokenList = tokenList;
        tokenList.add(new Token("end", SymbolTable.END, 0));
        this.parseList = new ArrayList<>();
        this.tkPtr = 1;
        this.curToken = tokenList.get(0);
        this.analyze();
    }

    public void analyze() {
        CompUnit();
    }

    public void getToken() {
        parseList.add(curToken.getType() + " " + curToken.getContent());
//        System.out.println(curToken.getType() + " " + curToken.getContent());
        curToken = tokenList.get(tkPtr);
        tkPtr++;
    }

    public ArrayList<String> getParseList() {
        return parseList;
    }

    public void error() {
        System.out.println("error");
        System.out.println(curToken.getType() + " " + curToken.getContent() + " " + curToken.getLine());
    }

    public void CompUnit() {
        while (curToken.type == SymbolTable.CONSTTK ||
                 (curToken.type == SymbolTable.INTTK && tokenList.get(tkPtr).type == SymbolTable.IDENFR &&
                         (tokenList.get(tkPtr+1).type == SymbolTable.LBRACK || tokenList.get(tkPtr+1).type == SymbolTable.ASSIGN || tokenList.get(tkPtr+1).type == SymbolTable.SEMICN || tokenList.get(tkPtr+1).type == SymbolTable.COMMA))) {
            Decl();
        }
        while ((curToken.type == SymbolTable.VOIDTK || curToken.type == SymbolTable.INTTK) && tokenList.get(tkPtr).type == SymbolTable.IDENFR && tokenList.get(tkPtr+1).type == SymbolTable.LPARENT) {
            FuncDef();
        }
        if (curToken.type == SymbolTable.INTTK && tokenList.get(tkPtr).type == SymbolTable.MAINTK) {
            MainFuncDef();
        } else {
            error();
        }
        parseList.add("<CompUnit>");
    }

    public void Decl() {
        if (curToken.type == SymbolTable.CONSTTK) {

            ConstDecl();
        }
        else if (curToken.type == SymbolTable.INTTK) {
            VarDecl();
        } else {
            error();
        }
    }

    public void FuncDef() {
        FuncType();
        if (curToken.type == SymbolTable.IDENFR) {
            getToken();
            if (curToken.type == SymbolTable.LPARENT) {
                getToken();
                if (curToken.type == SymbolTable.RPARENT) {
                    getToken();
                    Block();
                }
                else {
                    FuncFParams();
                    if (curToken.type == SymbolTable.RPARENT) {
                        getToken();
                        Block();
                    } else {
                        error();
                    }
                }
            }
        } else {
            error();
        }

        parseList.add("<FuncDef>");
    }

    public void FuncType() {
        if (curToken.type == SymbolTable.VOIDTK || curToken.type == SymbolTable.INTTK) {
            getToken();

        } else {
            error();
        }
        parseList.add("<FuncType>");
    }

    public void MainFuncDef() {
        getToken();
        getToken();
        if (curToken.type == SymbolTable.LPARENT) {
            getToken();
            if (curToken.type == SymbolTable.RPARENT) {
                getToken();
                Block();
            } else {
                error();
            }
        } else {
            error();
        }
        parseList.add("<MainFuncDef>");
    }

    public void Block() {
        if (curToken.type == SymbolTable.LBRACE) {
            getToken();
            if (curToken.type == SymbolTable.RBRACE) {
                getToken();
            }
            else {
                while (curToken.type != SymbolTable.RBRACE) {
                    BlockItem();
                }
                if (curToken.type == SymbolTable.RBRACE) {
                    getToken();
                } else {
                    error();
                }
            }
        } else {
            error();
        }
        parseList.add("<Block>");
    }

    public void BlockItem() {
        if (curToken.type == SymbolTable.CONSTTK || curToken.type == SymbolTable.INTTK) {
            Decl();
        }
        else if (curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.IFTK || curToken.type == SymbolTable.WHILETK
                    || curToken.type == SymbolTable.BREAKTK || curToken.type == SymbolTable.CONTINUETK || curToken.type == SymbolTable.RETURNTK
                    || curToken.type == SymbolTable.PRINTFTK || curToken.type == SymbolTable.SEMICN || curToken.type == SymbolTable.LBRACE
                    || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU
                    || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
            Stmt();
        }
    }

    public void Stmt() {
        if (curToken.type == SymbolTable.IFTK) {
            getToken();
            if (curToken.type == SymbolTable.LPARENT) {
                getToken();
                Cond();
                if (curToken.type == SymbolTable.RPARENT) {
                    getToken();
                    Stmt();
                } else {
                    error();
                }
                while (curToken.type == SymbolTable.ELSETK) {
                    getToken();
                    Stmt();
                }
            } else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.WHILETK) {
            getToken();
            if (curToken.type == SymbolTable.LPARENT) {
                getToken();
                Cond();
                if (curToken.type == SymbolTable.RPARENT) {
                    getToken();
                    Stmt();
                } else {
                    error();
                }
            } else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.BREAKTK) {
            getToken();
            if (curToken.type == SymbolTable.SEMICN) {
                getToken();
            }
        }
        else if (curToken.type == SymbolTable.CONTINUETK) {
            getToken();
            if (curToken.type == SymbolTable.SEMICN) {
                getToken();
            }
        }
        else if (curToken.type == SymbolTable.RETURNTK) {
            getToken();
            if (curToken.type == SymbolTable.SEMICN) {
                getToken();
            }
            else if (curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.INTCON || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT) {
                Exp();
                if (curToken.type == SymbolTable.SEMICN) {
                    getToken();
                } else {
                    error();
                }
            } else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.PRINTFTK) {
            getToken();
            if (curToken.type == SymbolTable.LPARENT) {
                getToken();
                if (curToken.type == SymbolTable.STRCON) {
                    getToken();
                    while (curToken.type == SymbolTable.COMMA) {
                        getToken();
                        Exp();
                    }
                    if (curToken.type == SymbolTable.RPARENT) {
                        getToken();
                        if (curToken.type == SymbolTable.SEMICN) {
                            getToken();
                        } else {
                            error();
                        }
                    } else {
                        error();
                    }
                } else {
                    error();
                }
            } else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.LBRACE) {
            Block();
        }
        else if (curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.INTCON || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT) {
            Exp();
            if (curToken.type == SymbolTable.SEMICN) {
                getToken();
            } else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.IDENFR) {
            int ptr = tkPtr;
            int assignFlag = 0;
            Token temp = tokenList.get(ptr);
            while (temp.type != SymbolTable.SEMICN) {
                if (temp.type == SymbolTable.ASSIGN) {
                    assignFlag = 1;
                    break;
                }
                ptr++;
                temp = tokenList.get(ptr);
            }
            if (assignFlag == 1) {
                if (tokenList.get(ptr + 1).type == SymbolTable.GETINTTK) {
                    LVal();
                    if (curToken.type == SymbolTable.ASSIGN) {
                        getToken();
                        if (curToken.type == SymbolTable.GETINTTK) {
                            getToken();
                            if (curToken.type == SymbolTable.LPARENT) {
                                getToken();
                                if (curToken.type == SymbolTable.RPARENT) {
                                    getToken();
                                    if (curToken.type == SymbolTable.SEMICN) {
                                        getToken();
                                    }
                                } else {
                                    error();
                                }
                            } else {
                                error();
                            }
                        } else {
                            error();
                        }
                    } else {
                        error();
                    }
                }
                // TODO
                else if (tokenList.get(ptr + 1).type == SymbolTable.LPARENT || tokenList.get(ptr + 1).type == SymbolTable.IDENFR || tokenList.get(ptr + 1).type == SymbolTable.PLUS || tokenList.get(ptr + 1).type == SymbolTable.MINU || tokenList.get(ptr + 1).type == SymbolTable.NOT || tokenList.get(ptr + 1).type == SymbolTable.INTCON) {
                    LVal();
                    if (curToken.type == SymbolTable.ASSIGN) {
                        getToken();
                        if (curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
                            Exp();
                            if (curToken.type == SymbolTable.SEMICN) {
                                getToken();
                            } else {
                                error();
                            }
                        } else {
                            error();
                        }
                    } else {
                        error();
                    }
                }
                else {
                    error();
                }
            }
            else {
                Exp();
                if (curToken.type == SymbolTable.SEMICN) {
                    getToken();
                } else {
                    error();
                }
            }
        }
        else if (curToken.type == SymbolTable.SEMICN) {
            getToken();
        }
        else {
            error();
        }
        parseList.add("<Stmt>");
    }

    public void Cond() {
        if (curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.INTCON || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT) {
            LOrExp();
        }
        parseList.add("<Cond>");
    }

    public void LOrExp() {
        LAndExp();
        parseList.add("<LOrExp>");
        while (curToken.type == SymbolTable.OR) {
            getToken();
            LAndExp();
            parseList.add("<LOrExp>");
        }
    }

    public void LAndExp() {
        EqExp();
        parseList.add("<LAndExp>");
        while (curToken.type == SymbolTable.AND) {
            getToken();
            EqExp();
            parseList.add("<LAndExp>");
        }
    }

    public void EqExp() {
        RelExp();
        parseList.add("<EqExp>");
        while (curToken.type == SymbolTable.EQL || curToken.type == SymbolTable.NEQ) {
            getToken();
            RelExp();
            parseList.add("<EqExp>");
        }
    }

    public void RelExp() {
        AddExp();
        parseList.add("<RelExp>");
        while (curToken.type == SymbolTable.LSS || curToken.type == SymbolTable.LEQ || curToken.type == SymbolTable.GRE || curToken.type == SymbolTable.GEQ) {
            getToken();
            AddExp();
            parseList.add("<RelExp>");
        }
    }

    public void ConstDecl() {
        if (curToken.type == SymbolTable.CONSTTK) {
            getToken();
            if (curToken.type == SymbolTable.INTTK) {
                getToken();
                ConstDef();
                while (curToken.type == SymbolTable.COMMA) {
                    getToken();
                    ConstDef();
                }
                if (curToken.type == SymbolTable.SEMICN) {
                    getToken();
                    parseList.add("<ConstDecl>");
                } else {
                    error();
                }
            } else {
                error();
            }
        } else {
            error();
        }
    }

    public void ConstDef() {
        if (curToken.type == SymbolTable.IDENFR) {
            getToken();
            while (curToken.type == SymbolTable.LBRACK) {
                getToken();
                ConstExp();
                if (curToken.type == SymbolTable.RBRACK) {
                    getToken();
                } else {
                    error();
                }
            }
            if (curToken.type == SymbolTable.ASSIGN) {
                getToken();
                ConstInitVal();
            } else {
                error();
            }
            parseList.add("<ConstDef>");
        } else {
            error();
        }
    }

    public void VarDecl() {
        if (curToken.type == SymbolTable.INTTK) {
            getToken();
            VarDef();
            while (curToken.type == SymbolTable.COMMA) {
                getToken();
                VarDef();
            }
            if (curToken.type == SymbolTable.SEMICN) {
                getToken();
                parseList.add("<VarDecl>");
            } else {
                error();
            }
        } else {
            error();
        }
    }

    public void VarDef() {
        if (curToken.type == SymbolTable.IDENFR) {
            getToken();
            while (curToken.type == SymbolTable.LBRACK) {
                getToken();
                ConstExp();
                if (curToken.type == SymbolTable.RBRACK) {
                    getToken();
                } else {
                    error();
                }
            }
            if (curToken.type == SymbolTable.ASSIGN) {
                getToken();
                InitVal();
                if (curToken.type != SymbolTable.COMMA && curToken.type != SymbolTable.SEMICN) {
                    error();
                }
            }
            parseList.add("<VarDef>");
        } else {
            error();
        }
    }

    // TODO
    public void ConstInitVal() {
        if (curToken.type == SymbolTable.LBRACE) {
            getToken();
            if (curToken.type == SymbolTable.LBRACE || curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
                ConstInitVal();
                while (curToken.type == SymbolTable.COMMA) {
                    getToken();
                    ConstInitVal();
                }
                if (curToken.type == SymbolTable.RBRACE) {
                    getToken();
                }
            }
            else if (curToken.type == SymbolTable.RBRACE) {
                getToken();
            }
            else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
            ConstExp();
        }
        else {
            error();
        }
        parseList.add("<ConstInitVal>");
    }

    public void InitVal() {
        if (curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
            Exp();
            parseList.add("<InitVal>");
        }
        else if (curToken.type == SymbolTable.LBRACE) {
            getToken();
            if (curToken.type == SymbolTable.RBRACE) {
                getToken();
            }
            else if (curToken.type == SymbolTable.LBRACE || curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
                InitVal();
                while (curToken.type == SymbolTable.COMMA) {
                    getToken();
                    InitVal();
                }
                if (curToken.type == SymbolTable.RBRACE) {
                    getToken();
                    parseList.add("<InitVal>");
                } else {
                    error();
                }
            }
        }
        else {
            error();
        }
//        parseList.add("<InitVal>");
    }

    public void ConstExp() {
        AddExp();
        parseList.add("<ConstExp>");
    }

    public void AddExp() {
        MulExp();
        parseList.add("<AddExp>");
        while (curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU) {
            getToken();
            MulExp();
            parseList.add("<AddExp>");
        }
    }

    public void MulExp() {
        UnaryExp();
        parseList.add("<MulExp>");
        while (curToken.type == SymbolTable.MULT || curToken.type == SymbolTable.DIV || curToken.type == SymbolTable.MOD) {
            getToken();
            UnaryExp();
            parseList.add("<MulExp>");
        }
    }

    public void UnaryExp() {
        if (curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.INTCON || (curToken.type == SymbolTable.IDENFR && tokenList.get(tkPtr).type != SymbolTable.LPARENT)) {
            PrimaryExp();
        }
        else if (curToken.type == SymbolTable.IDENFR && tokenList.get(tkPtr).type == SymbolTable.LPARENT) {
            getToken();
            getToken();
            if (curToken.type == SymbolTable.RPARENT) {
                getToken();
            }
            else if (curToken.type == SymbolTable.IDENFR || curToken.type == SymbolTable.LPARENT || curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT || curToken.type == SymbolTable.INTCON) {
                FuncRParams();
                if (curToken.type == SymbolTable.RPARENT) {
                    getToken();
                } else {
                    error();
                }
            }
            else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.PLUS || curToken.type == SymbolTable.MINU || curToken.type == SymbolTable.NOT) {
            UnaryOp();
            UnaryExp();
        }
        else {
            error();
        }
        parseList.add("<UnaryExp>");
    }

    public void UnaryOp() {
        getToken();
        parseList.add("<UnaryOp>");
    }

    public void PrimaryExp() {
        if (curToken.type == SymbolTable.LPARENT) {
            getToken();
            Exp();
            if (curToken.type == SymbolTable.RPARENT) {
                getToken();
            } else {
                error();
            }
        }
        else if (curToken.type == SymbolTable.IDENFR) {
            LVal();
        }
        else if (curToken.type == SymbolTable.INTCON) {
            Number();
        }
        else {
            error();
        }
        parseList.add("<PrimaryExp>");
    }

    public void Number() {
        getToken();
        parseList.add("<Number>");
    }

    public void LVal() {
        getToken();
        while (curToken.type == SymbolTable.LBRACK) {
            getToken();
            Exp();
            if (curToken.type == SymbolTable.RBRACK) {
                getToken();
            } else {
                error();
            }
        }
        parseList.add("<LVal>");
    }

    public void FuncFParams() {
        FuncFParam();
        while (curToken.type == SymbolTable.COMMA) {
            getToken();
            FuncFParam();
        }
        parseList.add("<FuncFParams>");
    }

    public void FuncFParam() {
        if (curToken.type == SymbolTable.INTTK) {
            getToken();
            if (curToken.type == SymbolTable.IDENFR) {
                getToken();
                if (curToken.type == SymbolTable.LBRACK) {
                    getToken();
                    if (curToken.type == SymbolTable.RBRACK) {
                        getToken();
                        while (curToken.type == SymbolTable.LBRACK) {
                            getToken();
                            ConstExp();
                            if (curToken.type == SymbolTable.RBRACK) {
                                getToken();
                            } else {
                                error();
                            }
                        }
                        parseList.add("<FuncFParam>");
                    } else {
                        error();
                    }
                }
                else if (curToken.type == SymbolTable.COMMA || curToken.type == SymbolTable.RPARENT) {
                    parseList.add("<FuncFParam>");
                }
                else {
                    error();
                }
            } else {
                error();
            }
        } else {
            error();
        }
    }

    public void FuncRParams() {
        Exp();
        while (curToken.type == SymbolTable.COMMA) {
            getToken();
            Exp();
        }
        parseList.add("<FuncRParams>");
    }

    public void Exp() {
        AddExp();
        parseList.add("<Exp>");
    }

}
